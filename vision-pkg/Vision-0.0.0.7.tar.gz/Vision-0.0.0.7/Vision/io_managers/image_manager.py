import os
import numpy as np
from PIL import Image
from Vision import Sample
from Vision.io_managers import Manager
from Vision.sample import Sample_List, Sample_Generator
from Vision.utils import image_utils
from Vision.utils.parallelisation import threadsafe_generator


class ImageManager(Manager):
    """Clase basica para cargar imagenes sin etiquetar desde un directorio."""

    def __init__(self, in_path: str, batch_size=32):
        super(ImageManager, self).__init__()
        self.batch_size = batch_size
        self.in_path = in_path
        self.file_list = list(filter(image_utils.is_image, os.listdir(self.in_path)))

    def read_sample(self, n) -> Sample:
        if n < 0:
            n = np.random.randint(0, len(self.file_list))
        img_name = self.file_list[n]
        img_path = os.path.join(self.in_path, img_name)
        return self.__to_sample(n, img_path)

    def write_sample(self, sample: Sample) -> int:
        print("This manager does not write samples.")
        return 0

    def __getitem__(self, index):
        idx0 = index * self.batch_size
        idx1 = min((index + 1) * self.batch_size, len(self.file_list))
        files = self.file_list[idx0:idx1]
        samples = list()
        for i in range(len(files)):
            file = os.path.join(self.in_path, files[i])
            sample_id = idx0 + i
            samples.append(self.__to_sample(sample_id, file))
        return samples

    def __len__(self):
        return int(np.ceil(len(self.file_list) / float(self.batch_size)))

    @threadsafe_generator
    def sample_generator(self, batch_size: int) -> Sample_Generator:
        assert self.in_path is not None, "No se ha especificado un path de donde leer las Imagenes"
        sample_id = 0
        samples = list()
        for file in self.__file_generator():
            samples.append(self.__to_sample(sample_id, file))
            sample_id += 1
            if len(samples) % batch_size == 0:
                out_samples = samples
                samples = list()
                yield out_samples
        yield samples

    def write_samples(self, samples: Sample_List) -> int:
        self.write_sample(samples[0])
        return 0

    def __file_generator(self):
        return image_utils.image_path_generator(self.in_path)

    def __to_sample(self, sample_id, file):
        """
        Carga una imagen y la convierte en un objeto Muestra sin anotaciones.
        :param sample_id: Id de la muestra.
        :param file: Nombre del fichero imagen.
        :return: Muestra sin anotaciones de la imagen.
        """
        img = Image.open(file)
        return Sample(sample_id, os.path.basename(file), img)
