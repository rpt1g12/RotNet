from Vision import Sample
from Vision.io_managers import Manager
from Vision.pipelines.pipeline import Pipeline
from Vision.sample import Sample_Generator, Sample_List


class PredictManager(Manager):
    """Pseudo-Sample-Manager that outputs results of the KmPipeline"""

    def __init__(self, pipe: Pipeline):
        super(PredictManager, self).__init__()
        self.pipe = pipe

    def set_batch_size(self, batch_size: int):
        self.pipe.get_sample_manager().set_batch_size(batch_size)

    def read_sample(self, n: int) -> Sample:
        sample = self.pipe.get_sample_manager().read_sample(n)
        return self.pipe.predict_sample(sample)

    def write_sample(self, sample: Sample, write_image=False) -> int:
        return 0

    def sample_generator(self, batch_size: int) -> Sample_Generator:
        return self.pipe.predict_batch(batch_size)

    def write_samples(self, samples: Sample_List, write_image=False) -> int:
        return 0

    def __getitem__(self, index):
        samples = self.pipe.get_sample_manager()[index]
        new_samples = list()
        for sample in samples:
            new_samples.append(self.pipe.predict_sample(sample))
        return new_samples

    def __len__(self):
        return len(self.pipe.get_sample_manager())


