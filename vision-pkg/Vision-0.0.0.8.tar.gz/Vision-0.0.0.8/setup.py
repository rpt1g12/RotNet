from setuptools import setup
from glob import glob

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name='Vision',
    version='0.0.0.8',
    install_requires=['numpy', 'tqdm', 'matplotlib', 'jinja2', 'keras>=2.2.4', 'imgaug', 'fontTools', 'h5py', 'Pillow',
                      'opencv-python', 'tensorflow>=1.15.0'],
    include_package_data=True,
    packages=['Vision',
              'Vision.io_managers', 'Vision.io_managers.utils',
              'Vision.models',
              'Vision.pipelines',
              'Vision.shapes',
              'Vision.utils'],
    data_files=[('Vision/io_managers/templates',  glob('Vision/io_managers/templates/*'))],
    url='',
    license='',
    author='LDAPRT',
    author_email='rafael.pereztorro@lineadirecta.es',
    description='Paquete para crear modelos de vision maquina'
)
