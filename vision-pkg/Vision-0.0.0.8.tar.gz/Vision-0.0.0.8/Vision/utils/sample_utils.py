import re
from typing import Callable

from Vision import Sample


def create_predicate_regex_tag(pattern: str) -> Callable[[Sample], bool]:
    """
    Creates a Predicate function that returns true if the most likely tag of
    a Sample matches a certain regex pattern.
    :param pattern: Regex pattern to match
    :return: A Predicate for samples that returns true if the most likely tag of
    a Sample matches a certain regex pattern.
    """
    regex = re.compile(pattern)

    def predicate_regex_tag(sample: Sample) -> bool:
        # Get most likely tag
        tags = sample.extract_tags()
        if tags:
            tag = list(sorted(tags.items(), key=lambda t: t[1], reverse=True))[0]
            return bool(regex.match(tag[0]))
        else:
            return False

    return predicate_regex_tag
